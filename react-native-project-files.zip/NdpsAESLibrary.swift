import Foundation
import CommonCrypto

@objc(NdpsAESLibrary) class NdpsAESLibrary: NSObject {

  @objc static func requiresMainQueueSetup() -> Bool { return true }
  
  @objc public func ndpsEncrypt(_ plainText: String, key: String, resolve: RCTPromiseResolveBlock, rejecter reject: RCTPromiseRejectBlock) -> Void {
    let encryptionResult = self.getAtomEncryption(plainText: plainText, key: key)
    resolve(encryptionResult)
  }
  
  @objc public func ndpsDecrypt(_ cipherText: String, key: String, resolve: RCTPromiseResolveBlock, rejecter reject: RCTPromiseRejectBlock) -> Void {
    let decryptionResult = self.getAtomDecryption(cipherText: cipherText, key: key)
    resolve(decryptionResult)
  }
  
  private func getAtomEncryption(plainText: String!, key: String!) -> String? {
        let pswdIterations:UInt32 = 65536
        let keySize:UInt = 32
        let ivBytes: Array<UInt8> = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
              let derivedKey = PBKDF.deriveKey(password: key,
                                               salt: key,
                                               prf: .sha512,
                                               rounds: pswdIterations,
                                               derivedKeyLength: keySize)
              let cryptor = Cryptor(operation: .encrypt,
                                    algorithm: .aes,
                                    options: [.PKCS7Padding],
                                    key: derivedKey,
                                    iv: ivBytes)
              let cipherText = cryptor.update(plainText)?.final()
              let hexStr = hexString(fromArray:cipherText.map{$0}!)
              return hexStr.uppercased()
    }

  private func hexString(fromArray : [UInt8], uppercase : Bool = false) -> String
    {
          return fromArray.map() { String(format:uppercase ? "%02X" : "%02x", $0) }.reduce("", +)
    }
      
  private func getAtomDecryption(cipherText: String!,
                             key: String!) -> String? {
          let pswdIterations:UInt32 = 65536
          let keySize:UInt = 32
          let ivBytes: Array<UInt8> = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
          
             let derivedKey = PBKDF.deriveKey(password: key,
                                              salt: key,
                                              prf: .sha512,
                                              rounds: pswdIterations,
                                              derivedKeyLength: keySize)
             let cryptor = Cryptor(operation: .decrypt,
                                   algorithm: .aes,
                                   options: [.PKCS7Padding],
                                   key: derivedKey,
                                   iv: ivBytes)
        if let data = hexadecimal(content: cipherText!),
                let decryptedPlainText = cryptor.update(data)?.final() {
                 let decryptedString = String(bytes: decryptedPlainText,
                                              encoding: .utf8)
                 return decryptedString
             }
             return nil
    }

  private func hexadecimal(content: String!) -> Data? {
              let regexPattern = "[0-9a-f]{1,2}";
              var data = Data(capacity: content.count / 2)
              let regex = try! NSRegularExpression(pattern: regexPattern,
                                                   options: .caseInsensitive)
              regex.enumerateMatches(in: content,
                                     options: [],
                                     range: NSMakeRange(0, content.count)) { match, flags, stop in
                  let byteString = (content as NSString).substring(with: match!.range)
                  var num = UInt8(byteString, radix: 16)!
                  data.append(&num, count: 1)
              }
              guard data.count > 0 else {
                  return nil
              }
              return data
    }
  
  @objc public func calculateHMAC(_ message:String, key:String, resolve: RCTPromiseResolveBlock, rejecter reject: RCTPromiseRejectBlock) -> Void {
    let hashedStr = message.hmac(hashKey: key)
    resolve(hashedStr)
  }
    
}

extension String {
    /// To get the formatted amount
    /// - Returns: Retuns the amount with proper decimal format
    func getFormattedAmount() -> String {
        let price = Double(self)
        let strPrice = String(format: "%.2f", price ?? 0.0)
        return strPrice
    }
    
    /// To get signature hex string
    /// - Parameter key: Pass the request hash key
    /// - Returns: Retuns the HMAC (HEX)string
    func hmac(hashKey key: String) -> String {
        var digest = [UInt8](repeating: 0,
                             count: Int(CC_SHA512_DIGEST_LENGTH))
        CCHmac(CCHmacAlgorithm(kCCHmacAlgSHA512),
               key,
               key.count,
               self,
               self.count,
               &digest)
        let data = Data(digest)
        return data.map { String(format: "%02hhx", $0) }.joined()
    }
    
}
