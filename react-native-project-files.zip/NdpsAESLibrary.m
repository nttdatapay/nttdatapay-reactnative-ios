#import <Foundation/Foundation.h>
#import "React/RCTBridgeModule.h"

@interface RCT_EXTERN_MODULE(NdpsAESLibrary, NSObject)


  RCT_EXTERN_METHOD(
    ndpsEncrypt: (NSString *)plainText
    key:(NSString *)key
    resolve: (RCTPromiseResolveBlock)resolve
    rejecter:(RCTPromiseRejectBlock)reject
  )

  RCT_EXTERN_METHOD(
    ndpsDecrypt: (NSString *)cipherText
    key:(NSString *)key
    resolve: (RCTPromiseResolveBlock)resolve
    rejecter:(RCTPromiseRejectBlock)reject
  )

  RCT_EXTERN_METHOD(
    calculateHMAC: (NSString *)message
    key:(NSString *)key
    resolve: (RCTPromiseResolveBlock)resolve
    rejecter:(RCTPromiseRejectBlock)reject
  )

@end
