import React, { useState } from 'react';
import { Linking, Text, View, ToastAndroid, Alert, NativeModules, StyleSheet, Modal, Pressable, Image, TouchableOpacity } from 'react-native';
import { WebView } from 'react-native-webview';
import PaymentHelper from './PaymentHelper';
const { NdpsAESLibrary } = NativeModules;

function Payment({ route, navigation }) {

  const [modalVisible, setModalVisible] = useState(false);
  const [phonePeVisible, setphonePeVisible] = useState(false);
  const [payTMVisible, setpayTMVisible] = useState(false);
  const [gPayVisible, setgPayVisible] = useState(false);
  const [upiURL, setupiURL] = useState('');

  const item = {
    phonePeLogoimg: require("./upi_intent_images/phonepe.png"),
    payTMLogoimg: require("./upi_intent_images/paytmLogo.png"),
    gPayLogoimg: require("./upi_intent_images/gpay.png")
  }

  const INJECT_JS = 'window.ReactNativeWebView.postMessage(document.getElementsByTagName("h5")[0].innerHTML)';
  const htmlPage = route.params.htmlPage;
  const merchantDetails = route.params.merchantDetails;

  decryptFinalResponse = async (data) => {

    let trimmedResponse = data.trim();
    let responseToastMsg = "";

    if (trimmedResponse.includes("cancelTransaction")) {
      console.log("Transaction has been cancelled");
      responseToastMsg = "Transaction has been cancelled";
    } else {
      var dataToEncrypt = "";
      var splitStr = trimmedResponse.split("|");
      if (trimmedResponse.indexOf("upiIntentResponse") > -1) {
        dataToEncrypt = splitStr[2].split("=");
        const decryptedStr = await NdpsAESLibrary.ndpsDecrypt(dataToEncrypt[1],
          merchantDetails.res_enc_key);
        console.log(decryptedStr);
        var upiParsedResponse = JSON.parse(decryptedStr);
        console.log(upiParsedResponse);
        if (upiParsedResponse["payInstrument"][0]["responseDetails"]["statusCode"] === "OTS0000") {
          console.log("upi intent response success");
          responseToastMsg = "Transaction success";
        } else {
          responseToastMsg = "Transaction failed";
        }
      } else {
        dataToEncrypt = splitStr[1].split("=");
        const decryptedStr = await NdpsAESLibrary.ndpsDecrypt(dataToEncrypt[1],
          merchantDetails.res_enc_key);
        var parsedResponse = JSON.parse(decryptedStr);
        console.log(parsedResponse);
        const ndps = new PaymentHelper();
        let signatureStr = ndps.createSigStr(parsedResponse); // create signature string
        const generatedSignatureStr = await NdpsAESLibrary.calculateHMAC(signatureStr, merchantDetails.response_hash_key); // hashing signature string with native function
        console.log(generatedSignatureStr);
        console.log(parsedResponse["payInstrument"]["payDetails"]["signature"]);
        if (generatedSignatureStr === parsedResponse["payInstrument"]["payDetails"]["signature"]) {
          if (parsedResponse["payInstrument"]["responseDetails"]["statusCode"] == 'OTS0000' || parsedResponse["payInstrument"]["responseDetails"]["statusCode"] == 'OTS0551') {
            console.log("Transaction success");
            responseToastMsg = "Transaction success";
          } else {
            console.log("Transaction failed");
            responseToastMsg = "Transaction failed";
          }
        } else {
          console.log("Signature mismatched ! Transaction failed");
          responseToastMsg = "Transaction failed";
        }
      }
    }

    // show toast messages as per the transaction status
    if (Platform.OS === 'android') {
      ToastAndroid.show(responseToastMsg, ToastAndroid.SHORT)
    } else {
      Alert.alert(responseToastMsg);
    }
    // closing WebView and return to homescreen once transaction response received
    navigation.goBack();

  }

  checkIfUPIAppsAvailable = async (url) => {
    const checkPhonePeApp = await Linking.canOpenURL('phonepe://');
    const checkPayTMApp = await Linking.canOpenURL('paytmmp://');
    const checkGpayApp = await Linking.canOpenURL('gpay://');

    setupiURL(url);

    checkPhonePeApp ? setphonePeVisible(true) : null;
    checkPayTMApp ? setpayTMVisible(true) : null;
    checkGpayApp ? setgPayVisible(true) : null;

    checkPhonePeApp || checkPayTMApp || checkGpayApp ? setModalVisible(true) : Alert.alert("Error occured !! \nkindly check if you have upi apps installed or not !");

  }

  initUPIPay = async (val) => {

    var payUrl = upiURL ? upiURL : null;

    if (val == 'phonepe') {
      let phonePeUrl = payUrl.replace("upi://pay", "phonepe://upi/pay");
      console.log(phonePeUrl);
      Alert.alert(phonePeUrl);
      Linking.openURL(phonePeUrl).catch(e => {
        Alert.alert("Error occured !! \nkindly check if you have phonepe app installed or not !");
      })
    }

    if (val == 'paytm') {
      let payTMUrl = payUrl.replace("upi://pay", "paytmmp://upi/pay");
      Alert.alert(payTMUrl);
      Linking.openURL(payTMUrl).catch(e => {
        Alert.alert("Error occured !! \nkindly check if you have paytm app installed or not !");
      })
    }

    if (val == 'gpay') {
      let gPayUrl = payUrl.replace("upi://pay", "gpay://upi/pay");
      Alert.alert(gPayUrl);
      Linking.openURL(gPayUrl).catch(e => {
        Alert.alert("Error occured !! \nkindly check if you have gpay app installed or not !");
      })
    }
  }

  return (

    <View style={{ flex: 1, padding: 0, margin: 0 }}>
      <WebView
        style={{ flex: 1 }}
        originWhitelist={["https://*", "upi://*"]}
        source={{ html: htmlPage }}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        renderLoading={this.LoadingIndicatorView}
        startInLoadingState={true}
        onShouldStartLoadWithRequest={request => {
          let url = request.url;
          if (url.startsWith('upi:')) {
            if (Platform.OS === 'android') {
              Linking.openURL(url).catch(e => {
                ToastAndroid.show("Error occured !! \nkindly check if you have upi apps installed or not !");
              })
              return false;
            } else {
              checkIfUPIAppsAvailable(url);
              return false;
            }
          }
          return true;
        }}
        onMessage={event => {
          if (event.nativeEvent.data.includes("encData") && event.nativeEvent.url.indexOf("mobilesdk/param") > -1) {
            decryptFinalResponse(event.nativeEvent.data);
          }
        }}
        injectedJavaScript={INJECT_JS}
        onError={syntheticEvent => {
          const { nativeEvent } = syntheticEvent;
          alert('WebView error: ', nativeEvent);
        }}
      />
      {!modalVisible ? null
        : <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            Alert.alert('Modal has been closed.');
            setModalVisible(!modalVisible);
          }}>
          <View style={styles.centeredViews}>
            <View style={styles.modalView}>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
                {phonePeVisible ?
                  <TouchableOpacity onPress={() => initUPIPay('phonepe')}>
                    <Image
                      style={{ width: 50, height: 50, margin: 10 }}
                      source={item.phonePeLogoimg}
                    />
                  </TouchableOpacity> : null
                }

                {payTMVisible ?
                  <TouchableOpacity onPress={() => initUPIPay('paytm')}>
                    <Image
                      style={{ width: 50, height: 50, margin: 10 }}
                      source={item.payTMLogoimg}
                      onPress={() => initUPIPay('payTM')}
                    />
                  </TouchableOpacity> : null
                }

                {gPayVisible ?
                  <TouchableOpacity onPress={() => initUPIPay('gpay')}>
                    <Image
                      style={{ width: 50, height: 50, margin: 10 }}
                      source={item.gPayLogoimg}
                      onPress={() => initUPIPay('gPay')}
                    />
                  </TouchableOpacity> : null
                }

              </View>
              <Pressable
                style={[styles.button, styles.buttonClose]}
                onPress={() => setModalVisible(!modalVisible)}>
                <Text style={{ textAlign: 'center', color: 'white' }}>Close</Text>
              </Pressable>
            </View>
          </View>
        </Modal>
      }
    </View>
  );
}

const styles = StyleSheet.create({
  centeredViews: {
    height: '100%',
    width: '100%',
    marginTop: 22,
    backgroundColor: 'transparent'
  },
  modalView: {
    justifyContent: 'center',
    alignItems: 'center',
    height: '30%',
    width: '100%',
    marginTop: 'auto',
    backgroundColor: 'white',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  buttonClose: {
    marginTop: 50,
    backgroundColor: 'grey',
    textAlign: 'center',
    alignContent: 'center',
  }
});

export default Payment;